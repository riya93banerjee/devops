myvar='shell scripting'
echo $myvar
